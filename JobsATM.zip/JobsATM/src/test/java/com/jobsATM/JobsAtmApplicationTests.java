package com.jobsATM;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobsAtmApplicationTests {

	@Test
	void contextLoads() {
	}

}
