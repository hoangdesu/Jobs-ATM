package com.jobsATM;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobsAtmApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobsAtmApplication.class, args);
	}

}
